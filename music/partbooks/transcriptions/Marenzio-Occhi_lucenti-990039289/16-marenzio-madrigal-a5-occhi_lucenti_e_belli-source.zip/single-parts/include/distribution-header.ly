    composer = "Luca Marenzio (c.1553-1599)"
    source = \markup { \italic { Il terzo libro de madrigali à 5 voci } (Venice, 1582) }
    style = "Renaissance"
    maintainer = "Allen Garvin"
    maintainerEmail = "allen.garvin@aurvondel.com"
    maintainerWeb = "http://blog.nitfol.com"
    booktitle = \markup { Typeset by Allen Garvin (aurvondel@gmail.com) (ver. #(strftime "%Y-%m-%d)" (localtime (current-time))) CC BY-NC 2.5 }
    tagline = #'f
